import numpy as np
from .SorryDaveAgent import SorryDaveAgent


def setup(self):
    weights = np.array([1.436, 0.557, -1.034, 0.628, -1.829, 1.052, -0.949, 1.32, 0.326, 0.426, 0.589, -0.407])
    self.agent = SorryDaveAgent(train=False, weights=weights, logger=self.logger)


def act(self, game_state: dict) -> str:
    return self.agent.act(game_state)
