from ._core import DQBase
